# GGIE'S TRAFFIC LIGHT — APK Build Guide

## Quick Play (No Build Required)
Open `app/src/main/assets/index.html` in any modern browser. Works perfectly on mobile Chrome/Firefox.

## Build Full APK with Android Studio

### Requirements
- Android Studio Hedgehog or newer
- JDK 17+
- Android SDK 34

### Steps
1. Open Android Studio → **Open Project** → select this folder (`ggies_apk/`)
2. Wait for Gradle sync to complete
3. Go to **Build → Build Bundle(s)/APK(s) → Build APK(s)**
4. APK will be at: `app/build/outputs/apk/debug/app-debug.apk`
5. Transfer to Android device and install (enable "Unknown Sources" in settings)

### Via Command Line (if Android SDK installed)
```bash
cd ggies_apk
./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release-unsigned.apk
```

## Features
- 🏎️ 15+ Top Supercars (Bugatti, Ferrari, Koenigsegg, etc.)
- ✈️ 5 Aircraft (F-22, SR-71, Apache, etc.)
- 🏍️ 5 Super Motorcycles (Ducati, Kawasaki H2R, etc.)
- 🚛 Trucks & Special vehicles
- 🚦 Accurate traffic light logic (Red 15s → Green 15s → Yellow 5s)
- 🗺️ 5000x5000 world with crossing roads & intersections
- 🕹️ On-screen joystick (hideable) + keyboard WASD/Arrow support
- 📊 Live telemetry dashboard
- 🎮 Arcade characters background
- 💰 Collectible coins & scoring
- 📷 3 camera modes
